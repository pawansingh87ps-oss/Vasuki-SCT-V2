#!/usr/bin/env python3
"""
dbtool.py - audit, migrate, index and purge the ACG / Vasuki database.

  python dbtool.py audit                          # read-only: what is really in the DB
  python dbtool.py migrate                        # DRY RUN of DB-CHANGE #1 (default, writes nothing)
  python dbtool.py migrate --apply --i-have-a-backup
  python dbtool.py indexes [--phase 2] [--apply] [--rebuild]
  python dbtool.py purge [--logs-days 400] [--apply]

Connection: --mongo-url / --db, or env MONGO_URL / DB_NAME (same as the backend).
Everything is idempotent and additive: it only fills fields that are missing and never
removes or rewrites existing values.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

import db_schema

START_KEYS = ("start_date", "start", "from_date", "valid_from", "amc_start")
END_KEYS = ("end_date", "end", "to_date", "valid_to", "expiry", "expiry_date", "amc_end")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def norm(s) -> str:
    return " ".join(str(s or "").split()).casefold()


def first(d: dict, keys):
    for k in keys:
        if d.get(k):
            return d[k]
    return None


# =============================================================== audit
def audit(db) -> dict:
    rep = {"collections": {}, "duplicates": {}, "warnings": []}
    for name in sorted(db.list_collection_names()):
        coll = db[name]
        docs = list(coll.find({}).limit(300))
        fields = defaultdict(lambda: {"n": 0, "types": set()})
        for d in docs:
            for k, v in d.items():
                fields[k]["n"] += 1
                fields[k]["types"].add(type(v).__name__)
        rep["collections"][name] = {
            "count": coll.count_documents({}),
            "indexes": sorted(coll.index_information().keys()),
            "fields": {k: {"seen_in_pct": round(100 * f["n"] / max(len(docs), 1)),
                           "types": sorted(f["types"])} for k, f in sorted(fields.items())},
        }

    def dups(coll, fn):
        seen = defaultdict(list)
        for d in db[coll].find({}):
            k = fn(d)
            if k:
                seen[k].append(str(d.get("id") or d["_id"]))
        return {k: v for k, v in seen.items() if len(v) > 1}

    checks = {
        "users.email": ("users", lambda d: norm(d.get("email"))),
        "users.username": ("users", lambda d: norm(d.get("username"))),
        "users.name": ("users", lambda d: norm(d.get("name"))),
        "customers.name": ("customers", lambda d: norm(d.get("name"))),
        "calls.call_no": ("calls", lambda d: d.get("call_no")),
        "calls.id": ("calls", lambda d: d.get("id")),
    }
    for label, (coll, fn) in checks.items():
        if coll in rep["collections"]:
            d = dups(coll, fn)
            if d:
                rep["duplicates"][label] = d
    for must in ("users", "calls", "customers", "amc", "sops"):
        if must not in rep["collections"]:
            rep["warnings"].append(f"collection '{must}' not found")
    return rep


# =============================================================== migrate (DB-CHANGE #1)
def _next_code(n: int) -> str:
    return f"CUST-{n:04d}"


def migrate(db, apply: bool = False, create_missing_customers: bool = False) -> dict:
    """DB-CHANGE #1 'Foundation v2.0' - links by id, counters, schema_meta. Additive + idempotent."""
    rep = {"apply": apply, "users": Counter(), "customers": Counter(), "calls": Counter(),
           "amc": Counter(), "warnings": [], "unmatched_customers": Counter(),
           "unmatched_users": Counter(), "possible_duplicate_customers": []}
    now = now_iso()

    def upd(coll, doc, fields):
        fields = {k: v for k, v in fields.items() if doc.get(k) in (None, "", []) and v not in (None, "")
                  and not (isinstance(v, list) and not v and k in doc)}
        if not fields:
            return False
        if apply:
            db[coll].update_one({"_id": doc["_id"]}, {"$set": fields})
        return True

    # ---- users -------------------------------------------------------------
    users = list(db.users.find({}))
    by_name = defaultdict(list)
    for u in users:
        by_name[norm(u.get("name"))].append(u)
        if upd("users", u, {"token_version": 0 if u.get("token_version") is None else u["token_version"],
                            "updated_at": u.get("created_at") or now}):
            rep["users"]["updated"] += 1
    # token_version 0 is falsy-safe because upd() treats only None/""/[] as missing
    user_id_by_name = {}
    for k, lst in by_name.items():
        if len(lst) == 1 and lst[0].get("id"):
            user_id_by_name[k] = lst[0]["id"]
        elif len(lst) > 1:
            rep["warnings"].append(f"users: {len(lst)} users share the name '{lst[0].get('name')}' - name links skipped")

    # ---- customers -----------------------------------------------------------
    customers = sorted(db.customers.find({}), key=lambda c: (c.get("created_at") or "", str(c["_id"])))
    nums = [int(m.group(1)) for c in customers for m in [re.search(r"(\d+)$", c.get("customer_code") or "")] if m]
    next_n = (max(nums) if nums else 0) + 1
    seen_keys = {}
    cust_id_by_key = {}
    for c in customers:
        key = norm(c.get("name"))
        fields = {"status": "Active", "aliases": [], "updated_at": c.get("created_at") or now}
        if not c.get("id"):
            fields["id"] = str(uuid.uuid4())
        if not c.get("customer_code"):
            fields["customer_code"] = _next_code(next_n)
            next_n += 1
        if key in seen_keys:  # duplicate name -> keep unique index buildable, flag for manual merge
            fields["name_key"] = f"{key}~dup{len(rep['possible_duplicate_customers']) + 1}"
            fields["status"] = "Duplicate?"
            fields["dup_of"] = seen_keys[key]
            rep["possible_duplicate_customers"].append({"name": c.get("name"), "duplicate_of": seen_keys[key]})
        else:
            fields["name_key"] = key
            seen_keys[key] = c.get("id") or fields.get("id")
            cust_id_by_key[key] = c.get("id") or fields.get("id")
        if upd("customers", c, fields):
            rep["customers"]["updated"] += 1

    # ---- amc -------------------------------------------------------------------
    amcs = list(db.amc.find({}))
    amcs_by_cust = defaultdict(list)
    date_keys_seen = False
    for a in amcs:
        cname = a.get("customer") or a.get("customer_name")
        cid = a.get("customer_id") or cust_id_by_key.get(norm(cname))
        if not a.get("id"):
            if apply:
                db.amc.update_one({"_id": a["_id"]}, {"$set": {"id": str(uuid.uuid4())}})
        if cid and not a.get("customer_id"):
            if apply:
                db.amc.update_one({"_id": a["_id"]}, {"$set": {"customer_id": cid, "updated_at": now}})
            rep["amc"]["linked_to_customer"] += 1
        elif not cid:
            rep["amc"]["unlinked"] += 1
        amcs_by_cust[cid].append(a)
        date_keys_seen = date_keys_seen or bool(first(a, START_KEYS) or first(a, END_KEYS))
    if amcs and not date_keys_seen:
        rep["warnings"].append("amc: no recognisable start/end date fields - calls.amc_id will be skipped "
                               "(run `audit` and tell me the real field names)")

    # ---- calls ---------------------------------------------------------------
    calls = list(db.calls.find({}))
    if create_missing_customers:
        missing = Counter()
        for c in calls:
            if not c.get("customer_id") and c.get("customer") and norm(c["customer"]) not in cust_id_by_key:
                missing[c["customer"].strip()] += 1
        done_keys = set()
        for name, _n in missing.most_common():
            k = norm(name)
            if k in done_keys:
                continue
            done_keys.add(k)
            cid = str(uuid.uuid4())
            doc = {"id": cid, "name": name, "name_key": k, "customer_code": _next_code(next_n),
                   "status": "Unverified", "aliases": [], "source": "migration", "created_at": now, "updated_at": now}
            next_n += 1
            if apply:
                db.customers.insert_one(doc)
            cust_id_by_key[k] = cid
            rep["customers"]["created_unverified"] += 1

    max_seq = 99999
    for c in calls:
        m = re.search(r"(\d+)$", c.get("call_no") or "")
        if m:
            max_seq = max(max_seq, int(m.group(1)))
        fields = {"updated_at": c.get("created_at") or now}
        if not c.get("id"):
            fields["id"] = str(uuid.uuid4())
        cid = cust_id_by_key.get(norm(c.get("customer")))
        if cid:
            fields["customer_id"] = cid
        elif c.get("customer"):
            rep["unmatched_customers"][c["customer"].strip()] += 1
        for src, dst in (("logged_by", "logged_by_id"), ("primary_resource", "primary_resource_id")):
            if c.get(src):
                uid = user_id_by_name.get(norm(c[src]))
                if uid:
                    fields[dst] = uid
                else:
                    rep["unmatched_users"][c[src].strip()] += 1
        sup = [p for p in re.split(r"\s*(?:,|;|/|&|\band\b)\s*", c.get("support_resource") or "") if p.strip()]
        sup_ids = [user_id_by_name[norm(p)] for p in sup if norm(p) in user_id_by_name]
        for p in sup:
            if norm(p) not in user_id_by_name:
                rep["unmatched_users"][p.strip()] += 1
        if sup_ids:
            fields["support_resource_ids"] = sup_ids
        if c.get("amc") in ("Yes", "No") and c.get("amc_covered") is None:
            fields["amc_covered"] = c["amc"] == "Yes"
        # best-effort AMC contract link by date window
        if cid and amcs_by_cust.get(cid):
            ld = (c.get("log_date") or "")[:10]
            hit = None
            for a in amcs_by_cust[cid]:
                s, e = first(a, START_KEYS), first(a, END_KEYS)
                s, e = (str(s)[:10] if s else ""), (str(e)[:10] if e else "")
                if (s or e) and ld and (not s or s <= ld) and (not e or ld <= e):
                    hit = a.get("id")
                    break
            if hit:
                fields["amc_id"] = hit
        if upd("calls", c, fields):
            rep["calls"]["updated"] += 1

    # ---- counters + schema_meta -----------------------------------------------
    rep["counters"] = {"call_no_seq_will_be": max_seq}
    if apply:
        db.counters.update_one({"_id": "call_no"}, {"$max": {"seq": max_seq}}, upsert=True)
        db.counters.update_one({"_id": "customer_code"}, {"$max": {"seq": next_n - 1}}, upsert=True)
        db.schema_meta.update_one(
            {"_id": "schema"},
            {"$set": {"version": db_schema.SCHEMA_VERSION, "updated_at": now},
             "$push": {"applied": {"version": db_schema.SCHEMA_VERSION, "change": "DB-CHANGE #1 foundation",
                                   "at": now}}}, upsert=True)
    for k in ("users", "customers", "calls", "amc", "unmatched_customers", "unmatched_users"):
        rep[k] = dict(rep[k].most_common(25) if isinstance(rep[k], Counter) and k.startswith("unmatched") else rep[k])
    return rep


# =============================================================== purge
def purge(db, logs_days: int | None = None, apply: bool = False) -> dict:
    """ISO-string dates cannot use Mongo TTL, so expired rows are removed here (run daily)."""
    now = datetime.now(timezone.utc)
    rep = {"otps": 0, "login_attempts": 0, "system_logs": 0, "apply": apply}
    q_otp = {"expires_at": {"$lt": now.isoformat()}}
    q_la = {"locked_until": {"$lt": (now - timedelta(days=1)).isoformat()}}
    rep["otps"] = db.otps.count_documents(q_otp)
    rep["login_attempts"] = db.login_attempts.count_documents(q_la)
    q_log = None
    if logs_days:
        q_log = {"timestamp": {"$lt": (now - timedelta(days=logs_days)).isoformat()}}
        rep["system_logs"] = db.system_logs.count_documents(q_log)
    if apply:
        db.otps.delete_many(q_otp)
        db.login_attempts.delete_many(q_la)
        if q_log:
            db.system_logs.delete_many(q_log)
    return rep


# =============================================================== CLI
def _print(obj):
    print(json.dumps(obj, indent=2, default=str, ensure_ascii=False))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["audit", "migrate", "indexes", "purge"])
    p.add_argument("--mongo-url", default=os.environ.get("MONGO_URL"))
    p.add_argument("--db", default=os.environ.get("DB_NAME"))
    p.add_argument("--apply", action="store_true", help="actually write (default is a dry run)")
    p.add_argument("--i-have-a-backup", action="store_true")
    p.add_argument("--create-missing-customers", action="store_true")
    p.add_argument("--phase", type=int, default=1)
    p.add_argument("--rebuild", action="store_true", help="drop+recreate conflicting legacy indexes")
    p.add_argument("--logs-days", type=int, default=None)
    a = p.parse_args(argv)
    if not a.mongo_url or not a.db:
        sys.exit("Set MONGO_URL and DB_NAME (or pass --mongo-url/--db).")
    from pymongo import MongoClient
    db = MongoClient(a.mongo_url, serverSelectionTimeoutMS=8000)[a.db]

    if a.command == "audit":
        _print(audit(db))
    elif a.command == "migrate":
        if a.apply and not a.i_have_a_backup:
            sys.exit("Refusing to write without --i-have-a-backup (take a mongodump first).")
        _print(migrate(db, apply=a.apply, create_missing_customers=a.create_missing_customers))
        if not a.apply:
            print("\nDRY RUN - nothing was written. Re-run with --apply --i-have-a-backup.")
    elif a.command == "indexes":
        if not a.apply:
            print("DRY RUN - would ensure these indexes (phase <= %d):" % a.phase)
            for coll, keys, opts, ph in db_schema.INDEXES:
                if ph <= a.phase:
                    print(f"  {coll} {keys} {opts}")
        else:
            _print(db_schema.apply_indexes(db, phase=a.phase, rebuild=a.rebuild))
            if a.phase >= 2:
                _print(db_schema.apply_validators(db))
    elif a.command == "purge":
        _print(purge(db, logs_days=a.logs_days, apply=a.apply))


if __name__ == "__main__":
    main()
