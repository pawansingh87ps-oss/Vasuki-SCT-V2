# DB Changelog

Every database change is numbered **DB-CHANGE #n**. Format: what changes · additive? · command · rollback · code that needs it.

---

## DB-CHANGE #1 — Foundation v2.0.0  (do BEFORE go-live)

**DB CHANGE: YES — additive only (no field or value is removed or overwritten).**

| Collection | Change |
|---|---|
| `users` | + `token_version` (0), `updated_at` |
| `customers` | + `customer_code`, `name_key`, `status`, `aliases`, `updated_at` (+ `id` if missing) |
| `amc` | + `customer_id`, `updated_at` (+ `id` if missing) |
| `calls` | + `customer_id`, `logged_by_id`, `primary_resource_id`, `support_resource_ids`, `amc_id`, `amc_covered`, `updated_at` |
| `counters` | NEW doc `call_no` (seeded to highest existing number), `customer_code` |
| `schema_meta` | NEW doc `schema` (`version: 2.0.0`, history) |
| indexes | unique `calls.call_no` (was non-unique), unique `customers.name_key/customer_code`, unique sparse `users.username`, query indexes on calls (see `db_schema.INDEXES`) |

Duplicate customer names are **not merged**: the later one is marked `status: "Duplicate?"` with `dup_of`, so the unique index can build and you merge them by hand in Customer Master.

### Rollout order (do not reorder)

0. **Backup.** `mongodump --uri "$MONGO_URL" --db "$DB_NAME" --out backup-$(date +%F)` (or Atlas export). Keep it off the server.
1. **Look first (read-only):** `python dbtool.py audit` → check `duplicates`, and compare the `fields` per collection with `DATA_MODEL_v2.md`. Tell me any field names that differ (especially `amc` dates).
2. **Deploy the new code first** (patch below). It tolerates both old and new data; startup index creation is non-fatal.
3. **Dry run:** `python dbtool.py migrate` → read `unmatched_customers`, `possible_duplicate_customers`, `warnings`.
4. **Apply:** `python dbtool.py migrate --apply --i-have-a-backup` (add `--create-missing-customers` if you prefer unknown names to become "Unverified" customers instead of staying unlinked).
5. **Indexes:** `python dbtool.py indexes` (dry run) → `python dbtool.py indexes --apply --rebuild`. `--rebuild` drops the old non-unique `call_no_1` and recreates it unique; it only succeeds if there are no duplicate call numbers (step 1 tells you).
6. **Verify:** `python dbtool.py audit` → `duplicates` empty; open the app → log a call → number is `max+1`.

### Required server.py edits (≈20 lines)

```python
# top of server.py
from db_schema import ensure_indexes_async, next_call_no, name_key, next_customer_code

# startup(): REPLACE the five create_index lines
#   await db.users.create_index("email", unique=True)
#   await db.calls.create_index("call_no") ... log_date, system_logs.timestamp, files.storage_path
# WITH:
    await ensure_indexes_async(db)          # never raises; logs a warning on trouble
```
> This replacement is **mandatory**. Once `call_no` is unique, the old line `create_index("call_no")` raises an index-options conflict and the portal would not start.

```python
# create_call(): REPLACE   count = await db.calls.count_documents({})  and  "call_no": "ACG"+str(100000+count)
    call_no = await next_call_no(db)
    cust = await db.customers.find_one({"name_key": name_key(body.get("customer"))}, {"_id": 0, "id": 1})
    primary_name = body.get("primary_resource", user["name"])
    primary = await db.users.find_one({"name": primary_name}, {"_id": 0, "id": 1})
    doc = {... "call_no": call_no, ...,
           "customer_id": cust["id"] if cust else None,
           "logged_by_id": user["id"],
           "primary_resource_id": primary["id"] if primary else None,
           "support_resource_ids": [],            # filled by the UI once it sends ids
           "amc_covered": body.get("amc", "Yes") == "Yes",
           "updated_at": now.isoformat()}
```
Customer create + Excel import: set `name_key=name_key(name)`, `customer_code=await next_customer_code(db)`, `status="Active"`, `aliases=[]`.
Auth (security release, same deploy): `create_token` adds `"tv": user.get("token_version", 0)`; `get_current_user` rejects when `payload.get("tv", 0) != user.get("token_version", 0)` or `not user.get("is_active", True)`.

**Rollback:** the change is additive, so old code keeps working. To undo fully: restore the backup, or `db.calls.update_many({}, {"$unset": {"customer_id":"","logged_by_id":"","primary_resource_id":"","support_resource_ids":"","amc_id":"","amc_covered":""}})` and drop `counters`/`schema_meta`.

---

## Planned (nothing runs until you approve each one)

| # | Change | Type | Needs |
|---|---|---|---|
| #2 | `sites`, `contacts`, `assets` + `calls.asset_id`; asset backfill from existing serials | new collections + additive | `dbtool` asset backfill (I'll write when we start it) |
| #3 | `calls.sla{}`, `app_settings.sla_policy` | additive | SLA policy numbers from you |
| #4 | `pm_schedules`, `pm_visits`, `assets.next_pm_due` | new | #2 |
| #5 | `handovers`, `email_outbox`, `notifications` | new | SMTP creds (Brevo/Gmail) |
| #6 | `problems`, `calls.problem_id` | new + additive | — |
| #7 | `calls.sop_ids_used`, text index `tx_calls` | additive | — |
| #8 | `ai_knowledge`, `ai_usage`, `ai_feedback` | new | AI phase B |
| #9 | KRA / feedback: engineer **name → user_id** | additive (+ later remove name keys) | #1 live for 2+ weeks |

Create phase-2 indexes/validators in one go when ready: `python dbtool.py indexes --phase 2 --apply`.

---

## Correction to my earlier suggestion
I earlier proposed TTL indexes on `otps.expires_at`, `login_attempts.locked_until` and `system_logs.timestamp`. **They would silently do nothing**: the app stores those as ISO *strings*, and MongoDB TTL only works on real dates. Use `python dbtool.py purge --apply` (daily), or convert those fields to real datetimes in a later release.
