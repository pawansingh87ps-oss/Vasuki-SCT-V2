# ACG Support 24x7 / Vasuki — Single-Source Data Model (schema v2)

Status: design + migration tooling ready. Schema version **2.0.0**.
Confidence key: **[code]** = confirmed in the backend source I reviewed; **[verify]** = inferred from docs/tests — run `python dbtool.py audit` against Atlas and correct this file before building on it.

---

## 1. The rule that makes it "one source of truth"

1. **Masters are written once, referenced everywhere by `id`.** Masters: `users`, `customers` (+ `sites`, `contacts`), `assets`, `amc`, `sops`, config lists in `app_settings`.
2. **Transactions point at masters by id**; the human-readable name is kept next to it only as a *snapshot* (so history survives a rename and today's code keeps working): `customer_id` + `customer`, `primary_resource_id` + `primary_resource`.
3. **Derived numbers are never stored.** Dashboard, champions, performance, per-person, open calls, non-AMC list, repeated-issue clusters, PM-due lists are all *queries* over `calls`, `pm_*`, `assets`. One edit to a call updates every module automatically.
4. **Names are never join keys again.** The old code scopes engineers with `{"$or":[{"logged_by":name}...]}` and lets users edit their own name — a rename silently changes who sees which calls. v2 scopes by `*_id`.
5. **Additive migrations only**, every one numbered `DB-CHANGE #n`, dry-run first, backup first (see `DB_CHANGELOG.md`).

---

## 2. Legacy portal vs current app — gap analysis

Legacy = `baseline.html` (16 tabs, Supabase). Current = React/FastAPI/Mongo. Current-app status is from the backend routes and page files; items marked *(verify in UI)* I could not click through because the repo went private.

| Legacy tab / behaviour | Current app | Verdict |
|---|---|---|
| Dashboard (status, RCA, region, platform, member, SW/HW, AMC split, top-10 customers) | Dashboard + filters/focus | Covered |
| Log a Call (30 fields) + Excel import template | LogCall + `/import/*` + configurable fields | Covered (better) |
| All Calls + Excel export + **Email shift report** | AllCalls + exporter | **Email shift report: gap** *(verify)* — legacy used `mailto:`; do it server-side (§3 #5) |
| Open & In-process calls + age alert bell | OpenCalls + `/notifications` | Covered; add SLA timers (§3 #3) |
| Champions (score = calls·3 + closed·2 + rate·30 + support − resp/10 + minutes/60) | Champions + weekly + KRA/MAPS | Covered (superset) |
| Performance | Performance | Covered |
| SOPs (Text/PDF/Word/PPT/Excel/Video) | Sops + file upload | Covered; add link-to-calls (§3 #8) |
| Non-AMC follow-up + "Alert Team Lead" (mailto) | NonAmc + `/calls/{id}/alert-lead`, close-reason | Covered (server-side) |
| Repeated issues (root cause × platform × system, ≥2) | RepeatedIssues scoring engine | Covered; upgrade to managed **Problems** (§3 #7) |
| **PM Follow-up** | PmFollowup is a placeholder in both | **Real gap** — build properly (§3 #4) |
| Team feedback (7-step form + dashboard) | Surveys + TeamFeedback + AI insights | Covered (superset) |
| Per Person review | PerPerson | Covered |
| Profile, Roles & Rights, System logs, About | Profile, RolesRights (+ per-user overrides), SystemLogs, About | Covered |
| Vasuki = rule-based nav + FAQ (works offline, no quota) | Vasuki = LLM only | **Keep the rule engine as fallback** (AI plan) |
| Realtime sync across users (Supabase realtime) | none seen | Gap — 30 s polling / SSE for open calls + notifications |
| *(not in legacy)* KRA/MAPS, AMC master, Customer master, branding, system config, lockout/OTP | present | New in current app |

**Bottom line:** the current app already covers all 16 legacy tabs. The real gaps are PM follow-up, the shift report/handover flow, realtime refresh, and — the bigger one — the *links between modules*, which today are name strings.

---

## 3. What to add (logical, useful, in priority order)

| # | Add | Why it earns its place | DB change | When |
|---|---|---|---|---|
| 1 | **Foundation links** (`customer_id`, `*_resource_id`, `amc_id`, atomic `call_no`, unique/query indexes) | Makes every module read the same records; fixes duplicate call numbers and rename breakage | **DB-CHANGE #1** (additive fields + `counters` + indexes) | **Before go-live** |
| 2 | **Installed base / Assets** (customer → site → system with serial, platform, version) | Today serial/version are free text per call. With assets: "all calls for this machine", "which customers run v2.1", PM and AMC coverage per machine | **DB-CHANGE #2** (new `sites`, `assets`, `contacts`; calls gain `asset_id`) | Week 1–2 |
| 3 | **SLA timers** (priority × AMC → response/resolve due, breach flag) | A 24x7 desk lives on this; also feeds the alert bell and champion fairness | **DB-CHANGE #3** (calls gain `sla{}`; policy in `app_settings.sla_policy`) | Week 2 |
| 4 | **PM scheduling** (per asset/AMC frequency → visits → checklist → report) | Replaces the placeholder; AMC revenue protection | **DB-CHANGE #4** (new `pm_schedules`, `pm_visits`; `assets.next_pm_due`) | Week 2–3 |
| 5 | **Shift handover + scheduled shift report** (open calls carried over, notes, acknowledge; report emailed by SMTP, not `mailto:`) | 4 shifts → handover is where calls get dropped. Replaces the legacy tab-separated email | **DB-CHANGE #5** (new `handovers`, `email_outbox`) | Week 1–2 |
| 6 | **Notifications** (persisted, per user) | Today computed on request; persisting enables read/unread, SLA and PM alerts | **DB-CHANGE #5b** (new `notifications`) | Week 2 |
| 7 | **Problems** (repeated issue → tracked record: owner, permanent fix, linked SOP, Jira) | Turns "we see it again and again" into "someone owns it" | **DB-CHANGE #6** (new `problems`; calls gain `problem_id`) | Week 3 |
| 8 | **Knowledge links** (SOP used on closure, "similar past calls" at log time) | Makes the SOP library and call history actually reused; feeds the AI | **DB-CHANGE #7** (calls gain `sop_ids_used[]`; text index `tx_calls`) | Week 3 |
| 9 | **Customer 360 page** | Pure UI over existing data: calls, AMC, assets, PM, contacts, problems | none | Week 3–4 |
| 10 | **AI knowledge/usage/feedback collections** | Quota guard, answer quality tracking | **DB-CHANGE #8** (new `ai_*`) | With AI phase B |

Deliberately **not** proposed: customer-facing ticket portal, billing/invoicing, inventory. Not needed for this team's job and each would double the surface to secure.

---

## 4. Entity relationships

```mermaid
erDiagram
  USERS ||--o{ CALLS : "logged_by_id / primary_resource_id / support_resource_ids"
  CUSTOMERS ||--o{ SITES : has
  CUSTOMERS ||--o{ CONTACTS : has
  CUSTOMERS ||--o{ AMC : "customer_id"
  SITES ||--o{ ASSETS : hosts
  CUSTOMERS ||--o{ ASSETS : owns
  AMC ||--o{ ASSETS : covers
  CUSTOMERS ||--o{ CALLS : "customer_id"
  ASSETS ||--o{ CALLS : "asset_id"
  AMC ||--o{ CALLS : "amc_id"
  ASSETS ||--o{ PM_SCHEDULES : "asset_id"
  PM_SCHEDULES ||--o{ PM_VISITS : generates
  USERS ||--o{ PM_VISITS : "engineer_id"
  CALLS }o--o{ SOPS : "sop_ids_used"
  CALLS }o--o| PROBLEMS : "problem_id"
  CALLS ||--o{ FILES : "owner_kind=call"
  HANDOVERS }o--o{ CALLS : "open_call_ids"
  USERS ||--o{ NOTIFICATIONS : receives
  USERS ||--o{ KRA : "engineer"
  USERS ||--o{ FEEDBACK : "member"
```

---

## 5. Collections

Common to every document: `id` (uuid string — the app's existing convention), `created_at`, `updated_at` (ISO UTC strings). Dates are **ISO strings** throughout the app, so MongoDB TTL indexes don't work — use `dbtool.py purge`.

### 5.1 Identity & access

**`users`** — EXISTING, +2 fields (DB-CHANGE #1)
| field | type | note |
|---|---|---|
| id, name, email, username, whatsapp, phone, designation, employee_code, photo | str | [code] |
| role | str | one of rbac `ROLES` [code] |
| shift | str | default shift [code] |
| is_active | bool | [code] — **must be checked on every request** (current code doesn't) |
| password_hash | str | bcrypt [code] |
| must_reset_password | bool | [code] — enforce server-side |
| permission_overrides | obj | per-module/feature [code] |
| last_login, last_shift, created_at | str | [code] |
| **token_version** | int | NEW — bump to revoke all sessions; embed in JWT |
| **updated_at** | str | NEW |

Indexes: unique `email`; unique sparse `username`, `id`; `(role,is_active)`.

**`rights`** [code] — role → module → feature booleans. Unique `role`. No change.
**`otps`**, **`login_attempts`** [code] — short-lived; cleaned by `dbtool purge`.

### 5.2 Masters

**`customers`** — EXISTING, +5 fields (DB-CHANGE #1)
| field | type | note |
|---|---|---|
| id, name, region, … | | [verify exact extra fields with `audit`] |
| **customer_code** | str | NEW, `CUST-0001`, unique, human-friendly, safe for emails/reports |
| **name_key** | str | NEW, casefolded+trimmed name, unique — prevents "Acme" vs "ACME " duplicates |
| **status** | str | NEW: Active / Inactive / Unverified / Duplicate? |
| **aliases** | [str] | NEW: other spellings, used by import + typeahead |
| **updated_at** | str | NEW |

**`amc`** — EXISTING, +2 fields (DB-CHANGE #1): `customer_id` (link), `updated_at`. Contract number/dates/coverage fields are [verify]. Phase 2 adds `response_sla_minutes`, `pm_frequency_months`, `coverage_notes`.

**`sites`** NEW (DB-CHANGE #2): `customer_id`, `name`, `city`, `region`, `address`, `timezone`.
**`contacts`** NEW (DB-CHANGE #2): `customer_id`, `site_id?`, `name`, `role`, `phone`, `email`, `is_primary`. Customer PII — visible to roles with `customer-master:view` only.
**`assets`** NEW (DB-CHANGE #2): `customer_id`, `site_id`, `amc_id?`, `platform`, `system_type`, `serial_no`, `sw_version`, `install_date`, `status` (Active/Retired/Spare), `last_pm_date`, `next_pm_due`. Unique `(customer_id, serial_no)`.
  *Backfill:* distinct `(customer_id, serial, platform, system_type, version)` from existing calls — mechanical, so assets can wait until after go-live **if serial numbers are entered consistently from day one**.

**`app_settings`** [code] — key/value config. Keys: `log_call_config` (dropdown lists: platforms, system types, issue types, regions, root causes, shifts), `support_members`, `branding`, `survey_insights`; NEW key `sla_policy`.

### 5.3 Calls (the heart)

**`calls`** — EXISTING, +9 fields (DB-CHANGE #1), +4 later
| field | type | note |
|---|---|---|
| id, call_no, created_at, log_date, log_time, shift, customer, region, location, amc ("Yes"/"No"), contact_name, contact_info, issue, issue_detail, jira, report_date/time, resolve_date, response_time, issue_type, platform, system_type, version, serial, priority, analysis, resolution, remarks, root_cause, primary_resource, support_resource, minutes, status, custom{}, timeline[], logged_by | | all [code] — **kept as snapshots** |
| **customer_id** | str | NEW #1 → customers.id |
| **logged_by_id**, **primary_resource_id** | str | NEW #1 → users.id |
| **support_resource_ids** | [str] | NEW #1 — legacy `support_resource` is a free-text, comma-separated string |
| **amc_id** | str? | NEW #1 → amc.id (contract active on `log_date`) |
| **amc_covered** | bool | NEW #1 — what the engineer *declared* (`amc=="Yes"`). Compare with `amc_id`: declared "No" but an active contract exists = revenue leak; declared "Yes" with no contract = billing risk |
| **updated_at** | str | NEW #1 |
| asset_id | str? | NEW #2 |
| sla{response_due, resolve_due, response_breached, resolve_breached} | obj | NEW #3 |
| problem_id | str? | NEW #6 |
| sop_ids_used[] | [str] | NEW #7 |

Indexes: unique `call_no` (**upgrade from non-unique**), `status+log_date`, `customer_id+log_date`, `primary_resource_id+log_date`, `shift+log_date`, `amc_covered+status`, `root_cause+platform+system_type`, text `tx_calls` (phase 2).
`call_no`: from the atomic `counters` document (`db_schema.next_call_no`), replacing `count_documents()`, which duplicates under concurrent saves or after any delete.

### 5.4 Knowledge & files

**`sops`** [code] — +later: `tags[]`, `version`, `owner_id`, `last_reviewed_at`, `file_ids[]`.
**`files`** [code] — +later: `owner_kind` (call/sop/pm_visit), `owner_id`, `uploaded_by_id`. Binary content moves from Emergent storage to **MongoDB GridFS** (see AI/hosting plan).

### 5.5 Operations (phase 2, new collections)

**`pm_schedules`**: `asset_id`, `amc_id?`, `frequency_months`, `next_due`, `assigned_to_id`, `checklist_template[]`, `status`.
**`pm_visits`**: `schedule_id`, `asset_id`, `planned_date`, `done_date`, `engineer_id`, `checklist[{item,ok,note}]`, `findings`, `report_file_id`, `call_id?`, `status` (Planned/In Progress/Done/Missed/Cancelled).
**`handovers`**: `date`, `shift_from`, `shift_to`, `from_user_id`, `to_user_id?`, `open_call_ids[]`, `notes`, `acknowledged_by_id`, `acknowledged_at`.
**`problems`**: `key` (root_cause|platform|system_type, unique), `title`, `call_ids[]` (or query by `problem_id`), `status`, `owner_id`, `permanent_fix`, `sop_id?`, `jira`, `resolved_at`.
**`notifications`**: `user_id`, `type`, `ref{kind,id}`, `title`, `created_at`, `read_at`.
**`email_outbox`**: `to[]`, `subject`, `body`, `attachment_file_ids[]`, `status` (queued/sent/failed), `ref{kind,id}`, `error`, `created_at`, `sent_at`.

### 5.6 People & performance [verify field names]

`kra_templates`, `kra_scores`/`kra` (MAPS), `feedback`/survey collections, `person_insights`, champions snapshots. These already key on engineer **name** — convert to `user_id` in DB-CHANGE #9 once the foundation is live (low risk, separate release).

### 5.7 AI (phase 2)

`vasuki_conversations` [code] (kept), `ai_knowledge` (indexed chunks of SOPs/closed calls, optional embeddings), `ai_usage` (per user per day — free-tier quota guard), `ai_feedback` (thumbs up/down per answer).

### 5.8 System

`system_logs` [code] — +later `actor_id`, `ref{kind,id}` (so "who changed call X" is a query, not a text search). `counters` NEW #1. `schema_meta` NEW #1 (current version + applied-change history).

---

## 6. Which module reads/writes what

| Module | Reads | Writes |
|---|---|---|
| Log Call | customers, amc, assets*, users, app_settings, sops*, calls (similar)* | calls, counters, files, system_logs |
| All / Open Calls | calls (+customers, users) | calls (status/timeline), notifications* |
| Dashboard / Champions / Performance / Per-Person | calls, users, kra | — (derived) |
| Non-AMC follow-up | calls where `amc_covered=false` | calls (close_reason), email_outbox* |
| Repeated issues → Problems | calls grouped by root_cause×platform×system | problems* |
| PM Follow-up | pm_schedules*, pm_visits*, assets*, amc | pm_visits*, calls (if issue found) |
| Handover | calls (open), users | handovers*, notifications* |
| SOPs | sops, calls (usage)* | sops, files |
| Customer / AMC master | customers, amc, contacts* | customers, amc, contacts* |
| KRA / Surveys | users, calls, feedback | kra, feedback |
| Vasuki (AI) | everything above through scoped read-only tools | vasuki_conversations, ai_usage* |
| Roles & Rights / Settings | users, rights, app_settings | same + system_logs |

`*` = arrives with its DB-CHANGE (phase 2). Everything in the "Dashboard" row stays derived — no stored totals, ever.

---

## 7. How DB changes are controlled (you asked to be told)

* Every change is numbered **DB-CHANGE #n** in `DB_CHANGELOG.md` with: what changes, whether it is **additive**, the migration command, rollback, and which code release needs it.
* `schema_meta.version` is bumped by the migration itself, so the DB always says which schema it is on.
* Order for every release: **backup → deploy code that tolerates both schemas → dry-run migration → apply → verify counts → remove old-schema fallbacks later**.
* I will always write "**DB CHANGE: yes/no**" at the top of any change I hand you.
