"""
db_schema.py - the single definition of the ACG / Vasuki database (schema v2).

Used by:
  * server.py startup -> `await ensure_indexes_async(db)`  (NEVER fatal)
  * server.py create_call -> `await next_call_no(db)`        (atomic call numbers)
  * dbtool.py            -> audit / migrate / indexes / purge

Rules
  1. Additive only. Legacy name fields (customer, primary_resource, ...) stay as
     display snapshots; new *_id fields are the real links.
  2. Every DB-changing release bumps SCHEMA_VERSION and is logged in
     docs/DB_CHANGELOG.md (look for "DB-CHANGE #n").
  3. Dates in this app are stored as ISO strings, so Mongo TTL indexes do NOT work
     on them. Use `dbtool.py purge` instead.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from pymongo import ReturnDocument
from pymongo.errors import OperationFailure

SCHEMA_VERSION = "2.0.0"
log = logging.getLogger("acg.schema")

# phase 1 = foundation (go-live).  phase 2 = new modules (create later, no data risk).
# (collection, keys, options, phase)
INDEXES = [
    # ---- identity & access -------------------------------------------------
    ("users", [("id", 1)], {"unique": True, "sparse": True}, 1),
    ("users", [("email", 1)], {"unique": True}, 1),                   # same as legacy startup index
    ("users", [("username", 1)], {"unique": True, "sparse": True}, 1),
    ("users", [("role", 1), ("is_active", 1)], {}, 1),
    ("rights", [("role", 1)], {"unique": True, "sparse": True}, 1),
    ("login_attempts", [("identifier", 1)], {"unique": True, "sparse": True}, 1),
    # ---- masters -------------------------------------------------------------
    ("customers", [("id", 1)], {"unique": True, "sparse": True}, 1),
    ("customers", [("customer_code", 1)], {"unique": True, "sparse": True}, 1),
    ("customers", [("name_key", 1)], {"unique": True, "sparse": True}, 1),
    ("amc", [("id", 1)], {"unique": True, "sparse": True}, 1),
    ("amc", [("customer_id", 1)], {"sparse": True}, 1),
    # ---- calls (the heart of the app) ---------------------------------------
    ("calls", [("id", 1)], {"unique": True, "sparse": True}, 1),
    ("calls", [("call_no", 1)], {"unique": True}, 1),                 # upgrades legacy non-unique index
    ("calls", [("log_date", 1)], {}, 1),                              # same as legacy startup index
    ("calls", [("status", 1), ("log_date", -1)], {}, 1),
    ("calls", [("customer_id", 1), ("log_date", -1)], {"sparse": True}, 1),
    ("calls", [("primary_resource_id", 1), ("log_date", -1)], {"sparse": True}, 1),
    ("calls", [("shift", 1), ("log_date", -1)], {}, 1),
    ("calls", [("amc_covered", 1), ("status", 1)], {"sparse": True}, 1),
    ("calls", [("root_cause", 1), ("platform", 1), ("system_type", 1)], {}, 1),  # repeated-issue grouping
    # ---- knowledge / files / logs -------------------------------------------
    ("sops", [("id", 1)], {"unique": True, "sparse": True}, 1),
    ("files", [("storage_path", 1)], {}, 1),                          # same as legacy startup index
    ("system_logs", [("timestamp", 1)], {}, 1),                       # same as legacy startup index
    ("system_logs", [("module", 1), ("timestamp", -1)], {}, 1),
    # ---- PHASE 2: new modules ------------------------------------------------
    ("contacts", [("id", 1)], {"unique": True}, 2),
    ("contacts", [("customer_id", 1)], {}, 2),
    ("sites", [("id", 1)], {"unique": True}, 2),
    ("sites", [("customer_id", 1)], {}, 2),
    ("assets", [("id", 1)], {"unique": True}, 2),
    ("assets", [("customer_id", 1), ("serial_no", 1)], {"unique": True, "sparse": True}, 2),
    ("assets", [("site_id", 1)], {"sparse": True}, 2),
    ("assets", [("next_pm_due", 1)], {"sparse": True}, 2),
    ("pm_schedules", [("id", 1)], {"unique": True}, 2),
    ("pm_schedules", [("asset_id", 1)], {}, 2),
    ("pm_schedules", [("status", 1), ("next_due", 1)], {}, 2),
    ("pm_visits", [("id", 1)], {"unique": True}, 2),
    ("pm_visits", [("schedule_id", 1), ("planned_date", 1)], {}, 2),
    ("pm_visits", [("engineer_id", 1), ("status", 1)], {}, 2),
    ("handovers", [("id", 1)], {"unique": True}, 2),
    ("handovers", [("date", -1), ("shift_to", 1)], {}, 2),
    ("problems", [("id", 1)], {"unique": True}, 2),
    ("problems", [("key", 1)], {"unique": True}, 2),
    ("problems", [("status", 1)], {}, 2),
    ("notifications", [("id", 1)], {"unique": True}, 2),
    ("notifications", [("user_id", 1), ("read_at", 1), ("created_at", -1)], {}, 2),
    ("email_outbox", [("id", 1)], {"unique": True}, 2),
    ("email_outbox", [("status", 1), ("created_at", 1)], {}, 2),
    ("ai_knowledge", [("source_kind", 1), ("source_id", 1)], {"unique": True}, 2),
    ("ai_usage", [("user_id", 1), ("day", 1)], {"unique": True}, 2),
    ("ai_feedback", [("message_id", 1)], {}, 2),
    # full-text search used by "similar past calls" and the AI tools
    ("calls", [("issue", "text"), ("issue_detail", "text"), ("analysis", "text"),
               ("resolution", "text"), ("root_cause", "text")], {"name": "tx_calls"}, 2),
]

# JSON-schema validators for NEW collections only (warn, never block writes).
_STR = {"bsonType": "string"}
VALIDATORS = {
    "assets": {"bsonType": "object", "required": ["id", "customer_id"],
               "properties": {"id": _STR, "customer_id": _STR, "serial_no": _STR,
                              "platform": _STR, "system_type": _STR, "sw_version": _STR,
                              "status": {"enum": ["Active", "Retired", "Spare"]}}},
    "pm_schedules": {"bsonType": "object", "required": ["id", "asset_id", "frequency_months", "status"],
                     "properties": {"frequency_months": {"bsonType": ["int", "long"], "minimum": 1},
                                    "status": {"enum": ["Active", "Paused", "Closed"]}}},
    "pm_visits": {"bsonType": "object", "required": ["id", "schedule_id", "planned_date", "status"],
                  "properties": {"status": {"enum": ["Planned", "In Progress", "Done", "Missed", "Cancelled"]}}},
    "handovers": {"bsonType": "object", "required": ["id", "date", "shift_from", "shift_to", "from_user_id"]},
    "problems": {"bsonType": "object", "required": ["id", "key", "status"],
                 "properties": {"status": {"enum": ["Open", "Investigating", "Fix Planned", "Resolved", "Ignored"]}}},
    "contacts": {"bsonType": "object", "required": ["id", "customer_id", "name"]},
    "sites": {"bsonType": "object", "required": ["id", "customer_id", "name"]},
}

PHASE2_COLLECTIONS = sorted({c for c, _k, _o, p in INDEXES if p == 2})


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _same_keys(info_key, keys) -> bool:
    return [tuple(k) for k in info_key] == [tuple(k) for k in keys]


# --------------------------------------------------------------------------- sync (dbtool, tests)
def apply_indexes(db, phase: int = 1, rebuild: bool = False) -> dict:
    """Create all indexes up to `phase`. On a conflicting legacy index: report it, or
    drop+recreate it when rebuild=True (only do that after `dbtool audit` shows no duplicates)."""
    out = {"ok": [], "conflict": [], "failed": [], "rebuilt": []}
    for coll, keys, opts, ph in INDEXES:
        if ph > phase:
            continue
        label = f"{coll}{keys}"
        try:
            db[coll].create_index(keys, **opts)
            out["ok"].append(label)
        except OperationFailure as e:
            if e.code in (85, 86):
                if not rebuild:
                    out["conflict"].append((label, str(e)[:160]))
                    continue
                try:
                    for name, info in db[coll].index_information().items():
                        if _same_keys(info["key"], keys) and name != "_id_":
                            db[coll].drop_index(name)
                    db[coll].create_index(keys, **opts)
                    out["rebuilt"].append(label)
                except Exception as e2:  # duplicates etc.
                    out["failed"].append((label, str(e2)[:160]))
            else:
                out["failed"].append((label, str(e)[:160]))
        except Exception as e:
            out["failed"].append((label, str(e)[:160]))
    return out


def apply_validators(db) -> dict:
    out = {"ok": [], "failed": []}
    existing = set(db.list_collection_names())
    for name, schema in VALIDATORS.items():
        try:
            if name in existing:
                db.command("collMod", name, validator={"$jsonSchema": schema},
                           validationLevel="moderate", validationAction="warn")
            else:
                db.create_collection(name, validator={"$jsonSchema": schema},
                                     validationLevel="moderate", validationAction="warn")
            out["ok"].append(name)
        except Exception as e:
            out["failed"].append((name, str(e)[:160]))
    return out


# --------------------------------------------------------------------------- async (server.py)
async def ensure_indexes_async(db, phase: int = 1) -> dict:
    """Call from the FastAPI startup hook. Never raises: a failed index must not stop the portal."""
    out = {"ok": 0, "conflict": [], "failed": []}
    for coll, keys, opts, ph in INDEXES:
        if ph > phase:
            continue
        try:
            await db[coll].create_index(keys, **opts)
            out["ok"] += 1
        except OperationFailure as e:
            bucket = "conflict" if e.code in (85, 86) else "failed"
            out[bucket].append(f"{coll}{keys}: {str(e)[:120]}")
        except Exception as e:  # noqa: BLE001
            out["failed"].append(f"{coll}{keys}: {str(e)[:120]}")
    await db.counters.update_one({"_id": "call_no"}, {"$max": {"seq": 99999}}, upsert=True)
    if out["conflict"] or out["failed"]:
        log.warning("Index issues (portal continues): %s", out)
    return out


async def next_call_no(db) -> str:
    """Atomic, collision-proof call number (replaces count_documents()). Self-heals if the
    counter is behind existing calls (e.g. migration not run yet)."""
    for _ in range(50):
        doc = await db.counters.find_one_and_update(
            {"_id": "call_no"}, {"$inc": {"seq": 1}}, upsert=True,
            return_document=ReturnDocument.AFTER)
        call_no = f"ACG{doc['seq']}"
        if not await db.calls.find_one({"call_no": call_no}, {"_id": 1}):
            return call_no
    raise RuntimeError("Could not allocate a call number")


def name_key(name) -> str:
    """Canonical form of a customer/user name: trimmed, single-spaced, case-folded."""
    return " ".join(str(name or "").split()).casefold()


async def next_customer_code(db) -> str:
    """CUST-0001, CUST-0002 ... atomic. Use when creating a customer (form or Excel import)."""
    for _ in range(50):
        doc = await db.counters.find_one_and_update(
            {"_id": "customer_code"}, {"$inc": {"seq": 1}}, upsert=True,
            return_document=ReturnDocument.AFTER)
        code = f"CUST-{doc['seq']:04d}"
        if not await db.customers.find_one({"customer_code": code}, {"_id": 1}):
            return code
    raise RuntimeError("Could not allocate a customer code")
