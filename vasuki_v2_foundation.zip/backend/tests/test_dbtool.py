"""Tests for dbtool.py / db_schema.py using mongomock (no real MongoDB needed).
Run:  cd backend && pip install mongomock pytest && pytest tests/test_dbtool.py -q
"""
import os
import sys

import mongomock
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import db_schema  # noqa: E402
import dbtool  # noqa: E402


@pytest.fixture()
def db():
    d = mongomock.MongoClient().db
    d.users.insert_many([
        {"id": "u1", "name": "Pawan", "email": "p@x.com", "username": "pawan", "role": "super_admin", "created_at": "2026-01-01"},
        {"id": "u2", "name": "Sri Harsha", "email": "s@x.com", "username": "sri", "role": "manager"},
        {"id": "u3", "name": "Talha", "email": "t@x.com", "username": "talha", "role": "engineer"},
        {"id": "u4", "name": "Twin", "email": "w1@x.com", "username": "w1", "role": "engineer"},
        {"id": "u5", "name": "twin", "email": "w2@x.com", "username": "w2", "role": "engineer"},
    ])
    d.customers.insert_many([
        {"id": "c1", "name": "Acme Pharma", "region": "West", "created_at": "2026-01-02"},
        {"id": "c2", "name": "ACME  pharma", "region": "West", "created_at": "2026-01-03"},   # dup by name
        {"id": "c3", "name": "Beta Labs", "region": "South", "created_at": "2026-01-04"},
    ])
    d.amc.insert_many([
        {"id": "a1", "customer": "Acme Pharma", "start_date": "2026-01-01", "end_date": "2026-12-31"},
        {"id": "a2", "customer": "Nobody Ltd", "start_date": "2026-01-01", "end_date": "2026-12-31"},
    ])
    d.calls.insert_many([
        {"id": "k1", "call_no": "ACG100000", "customer": "acme pharma", "logged_by": "Talha", "primary_resource": "Talha",
         "support_resource": "Sri Harsha, Talha", "amc": "Yes", "log_date": "2026-03-01", "created_at": "2026-03-01T10:00:00+00:00"},
        {"id": "k2", "call_no": "ACG100001", "customer": "Beta Labs", "logged_by": "Pawan", "primary_resource": "Twin",
         "support_resource": "", "amc": "No", "log_date": "2026-03-02"},
        {"id": "k3", "call_no": "ACG100250", "customer": "Ghost Hospital", "logged_by": "Ghost", "primary_resource": "Pawan",
         "support_resource": "Sri Harsha & Pawan", "amc": "No", "log_date": "2026-03-03"},
    ])
    return d


def test_dry_run_writes_nothing(db):
    before = list(db.calls.find({}, {"_id": 0}))
    rep = dbtool.migrate(db, apply=False)
    assert rep["apply"] is False
    assert list(db.calls.find({}, {"_id": 0})) == before
    assert db.counters.count_documents({}) == 0
    assert rep["counters"]["call_no_seq_will_be"] == 100250


def test_apply_links_everything_by_id(db):
    rep = dbtool.migrate(db, apply=True)
    k1 = db.calls.find_one({"id": "k1"})
    assert k1["customer_id"] == "c1"
    assert k1["logged_by_id"] == "u3" and k1["primary_resource_id"] == "u3"
    assert set(k1["support_resource_ids"]) == {"u2", "u3"}
    assert k1["amc_covered"] is True and k1["amc_id"] == "a1"
    k3 = db.calls.find_one({"id": "k3"})
    assert "customer_id" not in k3                       # Ghost Hospital unmatched
    assert set(k3["support_resource_ids"]) == {"u2", "u1"}  # '&' split
    assert k3["amc_covered"] is False
    assert rep["unmatched_customers"] == {"Ghost Hospital": 1}
    assert "Ghost" in rep["unmatched_users"]
    # ambiguous user name (Twin / twin) must NOT be linked
    assert "primary_resource_id" not in db.calls.find_one({"id": "k2"})
    assert any("share the name" in w for w in rep["warnings"])
    assert db.counters.find_one({"_id": "call_no"})["seq"] == 100250
    assert db.schema_meta.find_one({"_id": "schema"})["version"] == db_schema.SCHEMA_VERSION


def test_duplicate_customer_flagged_not_merged(db):
    rep = dbtool.migrate(db, apply=True)
    c2 = db.customers.find_one({"id": "c2"})
    assert c2["status"] == "Duplicate?" and c2["dup_of"] == "c1"
    assert c2["name_key"] != db.customers.find_one({"id": "c1"})["name_key"]
    assert len(rep["possible_duplicate_customers"]) == 1
    codes = [c["customer_code"] for c in db.customers.find({})]
    assert len(set(codes)) == 3 and all(c.startswith("CUST-") for c in codes)


def test_idempotent_and_never_overwrites(db):
    dbtool.migrate(db, apply=True)
    db.calls.update_one({"id": "k1"}, {"$set": {"customer_id": "MANUAL"}})
    snap = list(db.calls.find({}, {"_id": 0})) + list(db.customers.find({}, {"_id": 0}))
    rep2 = dbtool.migrate(db, apply=True)
    assert list(db.calls.find({}, {"_id": 0})) + list(db.customers.find({}, {"_id": 0})) == snap
    assert db.calls.find_one({"id": "k1"})["customer_id"] == "MANUAL"
    assert rep2["calls"].get("updated", 0) == 0 and rep2["customers"].get("updated", 0) == 0


def test_create_missing_customers(db):
    dbtool.migrate(db, apply=True, create_missing_customers=True)
    g = db.customers.find_one({"name": "Ghost Hospital"})
    assert g and g["status"] == "Unverified"
    assert db.calls.find_one({"id": "k3"})["customer_id"] == g["id"]


def test_unique_indexes_build_after_migration(db):
    dbtool.migrate(db, apply=True)
    res = db_schema.apply_indexes(db, phase=1)
    assert not res["failed"], res["failed"]
    with pytest.raises(Exception):
        db.calls.insert_one({"id": "dupe", "call_no": "ACG100000", "customer": "x"})


def test_audit_reports_duplicates(db):
    rep = dbtool.audit(db)
    assert "customers.name" in rep["duplicates"]
    assert "users.name" in rep["duplicates"]
    assert rep["collections"]["calls"]["count"] == 3


def test_purge_removes_only_expired(db):
    db.otps.insert_many([{"expires_at": "2020-01-01T00:00:00+00:00"}, {"expires_at": "2999-01-01T00:00:00+00:00"}])
    assert dbtool.purge(db, apply=False)["otps"] == 1 and db.otps.count_documents({}) == 2
    dbtool.purge(db, apply=True)
    assert db.otps.count_documents({}) == 1


def test_customer_code_counter_seeded_and_async_helper(db):
    import asyncio

    dbtool.migrate(db, apply=True)
    assert db.counters.find_one({"_id": "customer_code"})["seq"] == 3

    class AColl:
        def __init__(s, c): s.c = c
        def __getattr__(s, n):
            f = getattr(s.c, n)
            async def w(*a, **k): return f(*a, **k)
            return w
    class ADB:
        def __init__(s, d): s.d = d
        def __getattr__(s, n): return AColl(s.d[n])

    code = asyncio.run(db_schema.next_customer_code(ADB(db)))
    assert code == "CUST-0004"
    assert db_schema.name_key("  ACME   Pharma ") == "acme pharma"
